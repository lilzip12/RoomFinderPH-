
import React from 'react';
import { Barangay, Category, type Listing } from './types';

export const BARANGAYS = Object.values(Barangay);

export const MOCK_LISTINGS: Listing[] = [];
