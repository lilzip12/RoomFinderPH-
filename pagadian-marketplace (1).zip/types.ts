export enum Category {
  RENTAL = 'Room for Rent',
  PRODUCT = 'Local Product',
}

export enum Barangay {
  BALANGASAN = 'Balangasan',
  BANALE = 'Banale',
  DAO = 'Dao',
  DUMAGOC = 'Dumagoc',
  GATAS = 'Gatas',
  KAWAS = 'Kawas',
  LENING = 'Lening',
  SAN_PEDRO = 'San Pedro',
  SANTA_LUCIA = 'Santa Lucia',
  SANTO_NINO = 'Santo Niño',
  TIGUMA = 'Tiguma',
  TUBURAN = 'Tuburan',
}

export interface User {
  id: string;
  name: string;
  avatarUrl: string;
  gcash?: string;
}

export interface Review {
  user: Pick<User, 'name' | 'avatarUrl'>;
  rating: number;
  comment: string;
}

export interface NewListingData {
  title: string;
  category: Category;
  barangay: Barangay;
  price: number;
  priceUnit: 'month' | 'piece';
  description: string;
  imageData: string;
}

export interface Listing {
  id: string;
  title: string;
  category: Category;
  barangay: Barangay;
  price: number;
  priceUnit?: 'month' | 'piece';
  imageUrl: string;
  images: string[];
  description: string;
  rating: number;
  reviewCount: number;
  seller: User;
  isFlashDeal?: boolean;
  reviews: Review[];
}