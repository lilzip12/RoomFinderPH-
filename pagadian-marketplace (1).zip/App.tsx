
import React, { useState, useMemo, useEffect } from 'react';
import Header from './components/Header';
import PromoBanner from './components/PromoBanner';
import FlashDeals from './components/FlashDeals';
import ListingGrid from './components/ListingGrid';
import ListingDetailModal from './components/ListingDetailModal';
import FilterPill from './components/FilterPill';
import NewListingModal from './components/NewListingModal';
import Toast from './components/Toast';
import { type Listing, Category, Barangay, User, NewListingData } from './types';
import { MOCK_LISTINGS, BARANGAYS } from './constants';

const App: React.FC = () => {
    const [listings, setListings] = useState<Listing[]>([]);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [activeCategory, setActiveCategory] = useState<Category>(Category.RENTAL);
    const [selectedBarangay, setSelectedBarangay] = useState<Barangay | 'All'>('All');
    const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
    const [isNewListingModalOpen, setIsNewListingModalOpen] = useState(false);
    const [toast, setToast] = useState<{message: string; type: 'success' | 'error'} | null>(null);

    // Load listings from localStorage on initial render
    useEffect(() => {
        try {
            const savedListings = localStorage.getItem('roomfinderph_listings');
            if (savedListings) {
                setListings(JSON.parse(savedListings));
            } else {
                setListings(MOCK_LISTINGS); // Load mocks if nothing is saved
            }
        } catch (error) {
            console.error("Failed to load listings from localStorage", error);
            setListings(MOCK_LISTINGS);
        }
    }, []);

    // Save listings to localStorage whenever they change
    useEffect(() => {
        try {
            localStorage.setItem('roomfinderph_listings', JSON.stringify(listings));
        } catch (error) {
            console.error("Failed to save listings to localStorage", error);
        }
    }, [listings]);

    const filteredListings = useMemo(() => {
        return listings.filter(listing => {
            const categoryMatch = listing.category === activeCategory;
            const barangayMatch = selectedBarangay === 'All' || listing.barangay === selectedBarangay;
            return categoryMatch && barangayMatch;
        });
    }, [listings, activeCategory, selectedBarangay]);
    
    const flashDeals = useMemo(() => {
        return listings.filter(l => l.isFlashDeal);
    }, [listings]);
    
    const handleLogin = () => {
        // Simulate a user login
        const mockUser: User = {
            id: 'user_12345',
            name: 'Juan Dela Cruz',
            avatarUrl: 'https://i.pravatar.cc/150?u=currentuser',
            gcash: '09171234567'
        };
        setCurrentUser(mockUser);
        setToast({ message: `Welcome back, ${mockUser.name}!`, type: 'success'});
    };

    const handleLogout = () => {
        setCurrentUser(null);
    };

    const handleAddListing = (data: NewListingData) => {
        if (!currentUser) {
            setToast({ message: 'You must be logged in to post a listing.', type: 'error' });
            return;
        }
        const newListing: Listing = {
            id: `listing-${Date.now()}`,
            title: data.title,
            category: data.category,
            barangay: data.barangay,
            price: data.price,
            priceUnit: data.priceUnit,
            description: data.description,
            imageUrl: data.imageData,
            images: [data.imageData],
            seller: currentUser,
            rating: 0,
            reviewCount: 0,
            isFlashDeal: false,
            reviews: [],
        };
        setListings(prevListings => [newListing, ...prevListings]);
        setIsNewListingModalOpen(false);
        setToast({ message: 'Your listing has been posted successfully!', type: 'success' });
    };

    return (
        <div className="min-h-screen bg-brand-light font-sans text-brand-dark">
            <Header currentUser={currentUser} onLogin={handleLogin} onLogout={handleLogout} />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8">
                <PromoBanner />
                <FlashDeals deals={flashDeals} onSelectListing={setSelectedListing} />
                
                <div className="my-8">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-bold text-brand-dark">Explore Listings</h2>
                         {currentUser && (
                            <button
                                onClick={() => setIsNewListingModalOpen(true)}
                                className="bg-brand-accent hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg flex items-center transition-colors shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                                </svg>
                                Add Listing
                            </button>
                         )}
                    </div>
                    
                    {/* Category Filters */}
                    <div className="flex space-x-2 mb-4 border-b-2 border-yellow-200 pb-4">
                        <button 
                            onClick={() => setActiveCategory(Category.RENTAL)}
                            className={`px-6 py-2 rounded-t-lg font-semibold transition-colors duration-200 ${activeCategory === Category.RENTAL ? 'bg-brand-primary text-white' : 'bg-transparent text-brand-dark hover:bg-yellow-100'}`}
                        >
                            Rooms for Rent
                        </button>
                        <button 
                            onClick={() => setActiveCategory(Category.PRODUCT)}
                            className={`px-6 py-2 rounded-t-lg font-semibold transition-colors duration-200 ${activeCategory === Category.PRODUCT ? 'bg-brand-primary text-white' : 'bg-transparent text-brand-dark hover:bg-yellow-100'}`}
                        >
                            Local Products
                        </button>
                    </div>

                    {/* Barangay Filters */}
                    <div className="mb-6">
                        <h3 className="text-sm font-semibold text-gray-600 mb-3">Filter by Barangay:</h3>
                        <div className="flex flex-wrap gap-2">
                            <FilterPill
                                label="All Barangays"
                                isActive={selectedBarangay === 'All'}
                                onClick={() => setSelectedBarangay('All')}
                            />
                            {BARANGAYS.map(b => (
                                <FilterPill
                                    key={b}
                                    label={b}
                                    isActive={selectedBarangay === b}
                                    onClick={() => setSelectedBarangay(b)}
                                />
                            ))}
                        </div>
                    </div>

                    {filteredListings.length > 0 ? (
                        <ListingGrid listings={filteredListings} onSelectListing={setSelectedListing} />
                    ) : (
                        <div className="text-center py-16 bg-white rounded-lg shadow">
                            <h3 className="text-xl font-semibold text-brand-dark">No listings found</h3>
                            <p className="text-gray-500 mt-2">Try adjusting your filters or be the first to post!</p>
                        </div>
                    )}
                </div>
            </main>
            <ListingDetailModal listing={selectedListing} onClose={() => setSelectedListing(null)} />
            {isNewListingModalOpen && (
                <NewListingModal
                    isOpen={isNewListingModalOpen}
                    onClose={() => setIsNewListingModalOpen(false)}
                    onAddListing={handleAddListing}
                    currentUser={currentUser}
                />
            )}
            <Toast toast={toast} onClose={() => setToast(null)} />
            <footer className="bg-brand-primary text-yellow-50 mt-16 py-8">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <p>&copy; {new Date().getFullYear()} RoomFinderPH. All rights reserved.</p>
                    <p className="text-sm text-yellow-200 mt-1">Your Local Marketplace for Pagadian City.</p>
                </div>
            </footer>
        </div>
    );
};

export default App;